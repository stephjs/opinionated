exports.handler = function(event, context) {
  const Pusher = require('pusher');

  const pusher = new Pusher({
    appId: '331287',
    key: 'ff49622de873b6cf8048',
    secret: 'dc125053205b9ff26b6c',
    cluster: 'mt1',
    encrypted: true,
  });

  // single trigger
  pusher.trigger('channel', 'my-event', {
    message: 'hello world',
  });

  // multi channeltrigger
  pusher.trigger(['channel-1', 'channel-2'], 'my-event', {
    message: 'hello world',
  });

  // trigger batch
  console.log('triggering batch');
  pusher.triggerBatch([
    {
      channel: 'batch1',
      name: 'my-event',
      data: {message: 'hello-world'},
    },
    {
      channel: 'batch1',
      name: 'my-event2',
      data: {message: 'hello-moon'},
    },
  ]);

    context.done(null, 'It did actually run');
};
